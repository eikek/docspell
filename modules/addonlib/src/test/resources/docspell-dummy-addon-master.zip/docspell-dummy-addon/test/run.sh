#!/usr/bin/env bash

cdir=$(cd $(dirname "$0") && pwd)

mkdir -p "$cdir/target"

export ADDON_DIR="$cdir"
export TMPDIR="$cdir/target"
#export ITEM_DATA_JSON="item.json"

nix run . -- README.md
