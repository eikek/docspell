#!/nix/store/sa9h3gslr4jq0s2z22pyibwv5i7bj4ls-bash-interactive-5.1-p8/bin/bash


IP=/nix/store/fwxzhhvxfrh0a9c25sqi00nx964hm0ns-iproute2-5.14.0/bin/ip
TELNET=/nix/store/sqiphymcpky1yysgdc1aj4lr9jg9n53a-inetutils-2.2/bin/telnet
HOSTNAME=/nix/store/sqiphymcpky1yysgdc1aj4lr9jg9n53a-inetutils-2.2/bin/hostname
CORE=/nix/store/4dycifbpfg90py2ky101irwb54wjlmdy-coreutils-9.0/bin
ROUTE=/nix/store/ql0wis2l1ywi4f9xm0xn4074dsjr5rmx-net-tools-2.10/bin/route

$HOSTNAME
$CORE/cat /etc/resolv.conf
$ROUTE -n
$IP a


$TELNET eknet.org 80
#$TELNET localhost 7880
