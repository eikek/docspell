#!/usr/bin/env bash

mkdir -p target/chroot

IP=/nix/store/fwxzhhvxfrh0a9c25sqi00nx964hm0ns-iproute2-5.14.0/bin/ip
TELNET=/nix/store/sqiphymcpky1yysgdc1aj4lr9jg9n53a-inetutils-2.2/bin/telnet
CORE=/nix/store/4dycifbpfg90py2ky101irwb54wjlmdy-coreutils-9.0/bin

cp test.sh /tmp/target/test-temp/run-12540664468751148345/

sudo systemd-nspawn \
    -U -x \
    --no-pager \
    --as-pid2 \
    --bind-ro=/bin \
    --bind-ro=/usr/bin \
    --bind-ro=/nix/store \
    --bind-ro=/tmp/target/test-temp/run-12540664468751148345:/mnt \
    --machine=testcnt1 \
    --directory=/tmp/target/test-temp/run-12540664468751148345/chroot \
    --notify-ready=yes \
    --setenv=HOME=/mnt \
    --chdir /mnt \
    --private-network \
    ./test.sh

    # -p 7880 -n  \
    # --private-network \


# sudo systemd-nspawn \
#      -U \
#      --notify-ready=yes \
#      --ephemeral \
#      --as-pid2 \
#      --console=pipe \
#      --no-pager \
#      --bind-ro=/bin \
#      --bind-ro=/usr/bin \
#      --bind-ro=/nix/store \
#      --directory=/tmp/target/test-temp/run-12540664468751148345/chroot \
#      --machine=testcnt1 \
#      --setenv=HOME=/mnt \
#      --bind-ro=/tmp/target/test-temp/run-12540664468751148345:/mnt \
#      --chdir=/mnt \
#      -p 7880 -n \
#      --private-network \
#      -- /nix/store/sqiphymcpky1yysgdc1aj4lr9jg9n53a-inetutils-2.2/bin/telnet localhost 7880

#   --setenv PATH="$PATH" \
#    --setenv NIX_CONFIG="experimental-features = nix-command flakes" \
#    --setenv NIX_SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt \
#
