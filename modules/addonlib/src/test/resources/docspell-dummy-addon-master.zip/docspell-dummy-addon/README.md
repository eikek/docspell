# Addon Test

This is a dummy project implementing a docspell addon.
